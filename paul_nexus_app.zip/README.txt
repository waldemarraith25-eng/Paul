PAUL NEXUS – Web-App-Paket

Dateien:
- index.html: App-Oberfläche
- manifest.json: Installations-/PWA-Einstellungen
- sw.js: Offline-Cache für gehostete Version

So öffnen:
1. Entpacke paul_nexus_app.zip.
2. Öffne index.html in einem Browser, um die Demo zu testen.
3. Für eine installierbare PWA muss der Ordner auf einer HTTPS-Webadresse gehostet werden (z. B. GitHub Pages oder Cloudflare Pages); danach im Android-Browser-Menü „Zum Startbildschirm hinzufügen“ bzw. „App installieren“ wählen.

Wichtig:
- Dies ist keine kompilierte Android-APK.
- Login/Admin und Community sind in dieser Demo nicht serverseitig umgesetzt. Profil und Beiträge werden nur lokal im Browser gespeichert und sind nicht zwischen Nutzern synchronisiert.
- Für echte Konten, echte Community und geschützten Adminbereich braucht es ein Backend mit sicherer Authentifizierung.
